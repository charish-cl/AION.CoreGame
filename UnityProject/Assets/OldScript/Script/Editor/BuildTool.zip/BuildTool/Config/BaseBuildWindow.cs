﻿using Sirenix.OdinInspector.Editor;
using UnityEngine;

namespace GameDevKitEditor.BuildTool
{
    public abstract class BaseBuildWindow : OdinEditorWindow, IBuild
    {
        public BuildConfig _BuildConfig => BuildTool.BuildConfig;

        public abstract void BuildPackage();

        public void BuildAssetBundle()
        {
            if (_BuildConfig.IsBuildAtals)
            {
                Debug.Log("-----------------勾选了打图集，开始打图集----------------");
                var atlasPacker = GetWindow<SpriteAtlasPacker>();
                atlasPacker.PackProject();
            }
            BuildTool.ClearABRes();
            BuildTool.BuildResource("Assets/Game/BuildConfig/ResourceRuleEditor.asset");
            BuildTool.CopyResource();
        }

        public abstract void UpLoadPackage();

        public void UpLoadAssetBundle()
        {
            // 现在android 和 微信都使用 package 模式，不需要上传资源
            // BuildTool.UpLoadResourceToOSS();
        }

        public void PublishAssetBundle()
        {
            BuildTool.UpLoadVersionFile(DowloadPath());
        }

        public abstract void PublishPackage();

        public abstract string DowloadPath();

        public virtual void LocalBuild()
        {
            BuildAssetBundle();
            Debug.Log("打 AssetBundle 成功");
            BuildPackage();
            Debug.Log("打 Package 成功");
            UpLoadAssetBundle();
            Debug.Log("上传 AssetBundle 成功");
            UpLoadPackage();
            Debug.Log("上传 Package 成功");
            PublishPackage();
            Debug.Log("发布 Package 成功");
        }

        public virtual void RemoteBuild()
        {
            BuildAssetBundle();
            Debug.Log("打 AssetBundle 成功");
            BuildPackage();
            Debug.Log("打 Package 成功");
            UpLoadAssetBundle();
            Debug.Log("上传 AssetBundle 成功");
            UpLoadPackage();
            Debug.Log("上传 Package 成功");
            PublishPackage();
            Debug.Log("发布 Package 成功");
        }
    }
}