﻿using System;
using System.IO;
using System.Linq;
using Editor;
using Sirenix.OdinInspector;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace GameDevKitEditor.BuildTool
{
    [TreeWindow("打包工具/MacOS")]
    public class MacOSBuildWindow : BaseBuildWindow
    {

        /**
         * 打包之前一定需要打过资源。不然获取不到正确的资源id
         */
        public override void BuildPackage()
        {
            BuildTool.GenerateVersionInfo(BuildTool.GetInternalResourceVersionInResourceBuilder());
            BuildConfig BuildConfig = BuildTool.BuildConfig;
            BuildPlayerOptions buildPlayerOptions = new BuildPlayerOptions();
            BuildTargetGroup buildTargetGroup = BuildTargetGroup.Standalone;
            buildPlayerOptions.target = BuildTarget.StandaloneOSX;
            string DirectoryPath = BuildTool.GetOutPutFolder();
            if (!Directory.Exists(DirectoryPath))
            {
                Directory.CreateDirectory(DirectoryPath);
            }
#if ENABLE_HYBRIDCLR
            if (!(PlayerSettings.GetScriptingBackend(buildTargetGroup) == ScriptingImplementation.IL2CPP))
            {
                PlayerSettings.SetScriptingBackend(buildTargetGroup, ScriptingImplementation.IL2CPP);
                PlayerSettings.SetArchitecture(buildTargetGroup, 1);
            }
#else
            if (!(PlayerSettings.GetScriptingBackend(buildTargetGroup) == ScriptingImplementation.Mono2x))
            {
                PlayerSettings.SetScriptingBackend(buildTargetGroup, ScriptingImplementation.Mono2x);
                PlayerSettings.SetArchitecture(buildTargetGroup, 1);
            }
#endif
            string PackageName =
                $"{BuildConfig.RemoteFolderName}_{DateTime.Now.ToString().Replace(" ", "_").Replace("/", "_").Replace(':', '_')}";
            string PackagePath = $"{DirectoryPath}/{PackageName}";
            buildPlayerOptions.locationPathName = PackagePath;
            buildPlayerOptions.scenes = EditorBuildSettings.scenes.ToArray().Select(e => e.path).ToArray();

            BuildReport report = BuildPipeline.BuildPlayer(buildPlayerOptions);
            BuildSummary summary = report.summary;
            if (summary.result == BuildResult.Succeeded)
            {
                Debug.Log($"{BuildTool.Flag}BuildPackage succeeded: {PackagePath}" + summary.totalSize + " bytes");
            }
            else
            {
                throw new Exception($"{BuildTool.Flag}BuildPackage failed: {summary.result.ToString()}");
            }
        }

        public override void UpLoadPackage()
        {
            // nothing
        }
        
        public override string DowloadPath()
        {
            BuildConfig BuildConfig = BuildTool.BuildConfig;
            return $"{BuildConfig.CDNPackageUrl}";
        }

        public override void PublishPackage()
        {
            // nothing
        }
        
        public void LocalBuild()
        {
            BuildAssetBundle();
            Debug.Log("打 AssetBundle 成功");
            BuildPackage();
            Debug.Log("打 Package 成功");
            UpLoadAssetBundle();
            Debug.Log("上传 AssetBundle 成功");
            PublishAssetBundle();
            Debug.Log("发布 AssetBundle 成功");
        }
    }
}