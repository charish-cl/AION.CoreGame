﻿using System;
using System.IO;
using System.Linq;
using Editor;
using Sirenix.OdinInspector;
using UnityEditor;
using UnityEditor.Build.Reporting;
using UnityEngine;

namespace GameDevKitEditor.BuildTool
{
    [TreeWindow("打包工具/Android")]
    public class AndroidBuildWindow : BaseBuildWindow
    {
        [LabelText("是否在真机上测试")] public bool IsTestOnRealDevice = false;

        public static string PackagePath = "";
        public static string PackageName = "";
        
        public static void initKeyStore()
        {
            //秘钥名称：注意这里要加上.keystore后缀
            PlayerSettings.Android.keystoreName = "user.keystore";
            // 密钥密码
            PlayerSettings.Android.keystorePass = "nightq666";
            // 密钥别名
            PlayerSettings.Android.keyaliasName = "nightq";
            // 密钥别名密码
            PlayerSettings.Android.keyaliasPass = "nightq666";
        }

        /**
         * 打包之前一定需要打过资源。不然获取不到正确的资源id
         */
        public override void BuildPackage()
        {
            initKeyStore();
            BuildTool.GenerateVersionInfo(BuildTool.GetInternalResourceVersionInResourceBuilder());
            BuildConfig BuildConfig = BuildTool.BuildConfig;
            BuildPlayerOptions buildPlayerOptions = new BuildPlayerOptions();
            // 设置android不是导出工程
            EditorUserBuildSettings.exportAsGoogleAndroidProject = false;
            BuildTargetGroup buildTargetGroup = BuildTargetGroup.Android;
            buildPlayerOptions.target = BuildTarget.Android;
            string DirectoryPath = BuildTool.GetOutPutFolder();
            if (!Directory.Exists(DirectoryPath))
            {
                Directory.CreateDirectory(DirectoryPath);
            }
            string suffixes = "";
            Debug.Log($"{BuildTool.Flag}BuildPackage start: " +
                      $"{BuildConfig.BuildEnvironment}");
            if (BuildConfig.BuildEnvironment == BuildEnvironment.Release)
            {
                Debug.Log($"{BuildConfig.BuildEnvironment} BuildPackage start");
                buildPlayerOptions.options = BuildOptions.None | BuildOptions.CleanBuildCache;
                suffixes = ".apk";
                PlayerSettings.SetScriptingBackend(buildTargetGroup, ScriptingImplementation.IL2CPP);
                PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARM64;
            }
            else if (BuildConfig.BuildEnvironment == BuildEnvironment.Debug)
            {
                Debug.Log($"{BuildConfig.BuildEnvironment} BuildPackage start");
                buildPlayerOptions.options =
                    BuildOptions.Development | BuildOptions.AllowDebugging
                                             | BuildOptions.ConnectToHost | BuildOptions.ConnectWithProfiler;
                suffixes = ".apk";
                PlayerSettings.SetScriptingBackend(buildTargetGroup, ScriptingImplementation.Mono2x);
                PlayerSettings.Android.targetArchitectures = AndroidArchitecture.ARMv7;
            }

// #if ENABLE_HYBRIDCLR
//             if (!(PlayerSettings.GetScriptingBackend(buildTargetGroup) == ScriptingImplementation.IL2CPP))
//             {
//                 PlayerSettings.SetScriptingBackend(buildTargetGroup, ScriptingImplementation.IL2CPP);
//                 PlayerSettings.SetArchitecture(buildTargetGroup, 1);
//             }
// #else
//             if (!(PlayerSettings.GetScriptingBackend(buildTargetGroup) == ScriptingImplementation.Mono2x))
//             {
//                 PlayerSettings.SetScriptingBackend(buildTargetGroup, ScriptingImplementation.Mono2x);
//                 PlayerSettings.SetArchitecture(buildTargetGroup, 1);
//             }
// #endif

            PackageName =
                $"{BuildConfig.RemoteFolderName}_{DateTime.Now.ToString().Replace(" ", "_").Replace("/", "_").Replace(':', '_')}{suffixes}";
            PackagePath = $"{DirectoryPath}/{PackageName}";
            buildPlayerOptions.locationPathName = PackagePath;
            buildPlayerOptions.scenes = EditorBuildSettings.scenes.ToArray().Select(e => e.path).ToArray();

            BuildReport report = BuildPipeline.BuildPlayer(buildPlayerOptions);
            BuildSummary summary = report.summary;
            if (summary.result == BuildResult.Succeeded)
            {
                Debug.Log($"{BuildTool.Flag}BuildPackage succeeded: {PackagePath}" + summary.totalSize + " bytes");
            }
            else
            {
                throw new Exception($"{BuildTool.Flag}BuildPackage failed: {summary.result.ToString()}");
            }
        }

        public override void UpLoadPackage()
        {
            BuildTool.GenerateVersionInfo(BuildTool.GetInternalResourceVersionInResourceBuilder());
            // 上传apk
            BuildConfig BuildConfig = BuildTool.BuildConfig;
            string filePath = Path.GetFullPath($"{BuildTool.GetOutPutFolder()}/{PackageName}");
            Debug.Log($"{BuildTool.Flag} UpLoadPackage {filePath}");
            Debug.Log($"{BuildTool.Flag} UpLoadPackage {BuildConfig.UploadPackagePath} {PackagePath} ");
            OssTool.UpLoadOssFile(filePath, BuildConfig.UploadPackagePath + "/");
            Debug.Log($"{BuildTool.Flag} UpLoadPackage {BuildConfig.CDNPackageUrl} {PackageName}");
        }
        
        public override string DowloadPath()
        {
            BuildConfig BuildConfig = BuildTool.BuildConfig;
            Debug.Log($"{BuildTool.Flag} UpLoadPackage DowloadPath" +
                      $" {BuildConfig.CDNPackageUrl}/{PackageName}");
            return $"{BuildConfig.CDNPackageUrl}/{PackageName}";
        }

        public override void PublishPackage()
        {
            BuildTool.UpLoadVersionFile(DowloadPath());
        }
        
        public override void LocalBuild()
        {
            BuildTool.CompileDll();
            BuildAssetBundle();
            Debug.Log("打 AssetBundle 成功");
            BuildPackage();
            Debug.Log("打 Package 成功");
            // UpLoadAssetBundle();
            Debug.Log("上传 AssetBundle 成功");
            // PublishAssetBundle();
            Debug.Log("发布 AssetBundle 成功");
            Debug.Log("安装");
            Install();
        }

        public void Install()
        {
            CommandTool.InstallApk(PackagePath, IsTestOnRealDevice);
        }

        public override void RemoteBuild()
        {
            BuildAssetBundle();
            Debug.Log("打 AssetBundle 成功");
            BuildPackage();
            Debug.Log("打 Package 成功");
            UpLoadAssetBundle();
            Debug.Log("上传 AssetBundle 成功");
            UpLoadPackage();
            Debug.Log("上传 Package 成功");
            PublishPackage();
            Debug.Log("发布 Package 成功");
        }
    }
}