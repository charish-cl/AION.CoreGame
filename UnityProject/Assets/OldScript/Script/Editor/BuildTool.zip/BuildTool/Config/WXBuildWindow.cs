﻿// using System;
// using System.Diagnostics;
// using System.IO;
// using System.Linq;
// using System.Reflection;
// using System.Threading.Tasks;
// using AION.CoreFramework.Editor;
// using Sirenix.OdinInspector;
// using TMPro;
// using UnityEditor;
// using UnityEditor.SceneManagement;
// using UnityEngine;
// using UnityGameFramework.Runtime;
// using WeChatWASM;
// using Debug = UnityEngine.Debug;
//
// namespace GameDevKitEditor.BuildTool
// {
//     [TreeWindow("打包工具/WX")]
//     public class WXBuildWindow : BaseBuildWindow
//     {
//         private string OutPutRootFolder => Path.GetFullPath($"{BuildTool.GetOutPutFolder()}");
//
//         public string outputProjectPath => Path.Combine(
//             OutPutRootFolder, "minigame");
//
//         [Button("打开微信小程序", ButtonHeight = 40)]
//         public static void OpenWX()
//         {
//             string path = "C:\\Program Files (x86)\\Tencent\\微信web开发者工具";
//
//             ShellHelper.RunMultiple(
//                 $"cd {path}",
//                 "微信开发者工具.exe -disable-gpu"
//             );
//         }
//
//        public string preloadFiles =
//             "Scenes;Prefabs;FontMat;UIForm;UIComponent;CommonSprites;MainSprites;SpriteData;ChessBoard;" +
//             "Textures;Materials;Animations;Datas;";
//        public string localCDN = "http://192.168.0.2:8880/webgl";
//         public override void BuildPackage()
//         {
//             BuildTool.GenerateVersionInfo(BuildTool.GetInternalResourceVersionInResourceBuilder());
//
//             #region 初始化打包配置
//             Debug.Log($"{BuildTool.Flag} BuildPackage " + OutPutRootFolder
//                                             + " CDNPackageUrl " + _BuildConfig.CDNPackageUrl);
//             
//             Debug.Log(WXConvertCore.config.ProjectConf.MemorySize);
//             var compileOptions = WXConvertCore.config.CompileOptions;
//
//             WXConvertCore.config.ProjectConf.preloadFiles = preloadFiles;
//             Debug.Log("preloadFiles " + WXConvertCore.config.ProjectConf.preloadFiles);
//                 compileOptions.DevelopBuild = false;
//                 compileOptions.AutoProfile = false;
//                 compileOptions.fbslim = true;
//                 compileOptions.ProfilingMemory = false;
//                 compileOptions.profilingFuncs = true;
//                 compileOptions.CleanBuild = true;
//                 WXConvertCore.config.CompressTexture.debugMode = false;
//             compileOptions.enableIOSPerformancePlus = true;
//             WXConvertCore.config.ProjectConf.compressDataPackage = true;
//             WXConvertCore.config.ProjectConf.MemorySize = 768;
//             WXConvertCore.config.ProjectConf.Orientation = 0;
//             WXConvertCore.config.ProjectConf.needCheckUpdate = true;
//             WXConvertCore.config.CompileOptions.Webgl2 = true;
//             
//             if (_BuildConfig.UserLocalCDN)
//             {
//                 //调试模式默认用本地
//                 WXConvertCore.config.ProjectConf.CDN = localCDN;
//             }
//             else
//             {
//                 //打包时动态的CDN
//                 WXConvertCore.config.ProjectConf.CDN = _BuildConfig.CDNPackageUrl;
//             }
//             // 为了防止缓存异常先删除，后面如果证明没问题可以去掉。
//             // Directory.Delete(OutPutRootFolder);
//             if (!Directory.Exists(OutPutRootFolder))
//             {
//                 Directory.CreateDirectory(OutPutRootFolder);
//             }
//             WXConvertCore.config.ProjectConf.DST = OutPutRootFolder;
//             #endregion 初始化打包配置
//             // 开始打底包
//             WXConvertCore.WXExportError error = WXConvertCore.DoExport();
//             if (error == WXConvertCore.WXExportError.SUCCEED)
//             {
//                 Debug.Log("成功");
//             }
//             else
//             {
//                 Debug.LogError("失败");
//                 throw new Exception($" {BuildTool.Flag} error {error.ToString()}");
//             }
//         }
//
//         public override void UpLoadPackage()
//         {
//             // 先在Task外部将变量赋值给临时变量
//             BuildTool.GenerateVersionInfo(BuildTool.GetInternalResourceVersionInResourceBuilder());
//             string uploadPackagePath = _BuildConfig.UploadPackagePath;
//             string outputRootFolder = OutPutRootFolder;
//
//             Task.Run(async () =>
//             {
//                 var stopwatch = new Stopwatch();
//                 stopwatch.Start();  // 开始计时
//
//                 // 指定要搜索的目录
//                 string directoryPath = Path.Combine(outputRootFolder, "webgl");
//                 string streamAssetsPath = Path.Combine(outputRootFolder, "webgl/StreamingAssets");
//
//                 try
//                 {
//                     // 找到所有名字里含有 webgl.data.unityweb 的文件
//                     string[] files = Directory.GetFiles(directoryPath, "*webgl.data.unityweb*");
//                     if (files.Length == 0)
//                     {
//                         Debug.LogError("No files found matching the pattern *webgl.data.unityweb*.");
//                         return;
//                     }
//
//                     Debug.Log($"{BuildTool.Flag} UpLoadPackage " + uploadPackagePath + " " + outputRootFolder);
//
//                     // 创建并行上传任务
//                     var uploadTasks = files.Select(filePath => Task.Run(() => OssTool.UpLoadOssFile(filePath, uploadPackagePath + "/"))).ToList();
//
//                     // 上传 StreamingAssets 文件夹
//                     uploadTasks.Add(Task.Run(() => OssTool.UpLoadOssFolder(streamAssetsPath, uploadPackagePath + "/StreamingAssets/")));
//
//                     // 等待所有上传任务完成
//                     await Task.WhenAll(uploadTasks);
//                 }
//                 catch (Exception ex)
//                 {
//                     Debug.LogError($"Error during upload: {ex.Message}");
//                 }
//                 finally
//                 {
//                     stopwatch.Stop();  // 停止计时
//                     Debug.Log($"Upload completed in {stopwatch.Elapsed.TotalSeconds} seconds.");
//                 }
//             });
//         }
//
//         public override string DowloadPath()
//         {
//             return "https://mp.weixin.qq.com/wxamp/wacodepage/getcodepage?token=1313100240&lang=zh_CN";
//         }
//         
//         public override void PublishPackage()
//         {
//             string workDirectory = "";
//             string command = "";
// #if UNITY_EDITOR_WIN
//             workDirectory = "C:\\Program Files (x86)\\Tencent\\微信web开发者工具";
//             command =
//                 $"cli upload --project \"{outputProjectPath}\" -v \"{_BuildConfig.Version}\" -d \"{_BuildConfig.Describe}\"";
// #elif UNITY_EDITOR_OSX
// //前面一定不能有空格
//             workDirectory = "/Applications/wechatwebdevtools.app/Contents/MacOS/";
//             command =
//  $"cd {workDirectory}; ./cli upload --project \"{outputProjectPath}\" -v \"{_BuildConfig.Version}\" -d \"{_BuildConfig.Describe}\"";
// #endif
//             // 将批处理脚本写入临时文件
//             ShellHelper.Run(command, workDirectory);
//             Debug.Log($"{BuildTool.Flag} Batch script executed.");
//             // 上报资源更新
//             BuildTool.UpLoadVersionFile(DowloadPath());
//         }
//         public override void LocalBuild()
//         {
//             Debug.Log("添加微信宏");
//             //添加宏
//       //      ScriptingDefineSymbols.AddScriptingDefineSymbol(BuildTargetGroup.WebGL, "WX");
//             //  UnityEditor.EditorSettings.spritePackerMode = SpritePackerMode.SpriteAtlasV2Build;
//             // 这样打包时就不会将字体文件打包，而是只打包图集。现在已经是静态字了，不需要这个了
//             //  TMP_Settings.GetFontAsset().atlasPopulationMode = AtlasPopulationMode.Static;
//             FontPreHandle();
//             //只打包首场景
//            DisableAllScenesExceptFirst();
//
//            
//            BuildAssetBundle();
//            Debug.Log("打 AssetBundle 成功");
//            BuildPackage();
//            Debug.Log("打 Package 成功");
//            UpLoadPackage();
//            Debug.Log("上传 Package 成功");
//           // UpLoadAssetBundle();
//           // Debug.Log("上传 AssetBundle 成功");
//            
//            // if (_BuildConfig.BuildEnvironment != BuildEnvironment.Debug)
//            // {
//            //     UpLoadPackage();
//            // }
//         
//           // Debug.Log("上传 Package 成功");
//
//     //       ScriptingDefineSymbols.RemoveScriptingDefineSymbol(BuildTargetGroup.WebGL, "WX");
//
//             //   TMP_Settings.GetFontAsset().atlasPopulationMode = AtlasPopulationMode.Dynamic;
//             // UnityEditor.EditorSettings.spritePackerMode = SpritePackerMode.Disabled;
//             
//             FontPostHandle();
//           EnableAllScenes();
//
//           // string htmlIndexPath = Path.Combine(Application.dataPath, "../Build/WebGL/WXMini/webgl/index.html");
//           // if (File.Exists(htmlIndexPath))
//           // {
//           //   File.Delete(htmlIndexPath);  
//           // }
//         }
//
//
//         [Button]
//         public void FontPreHandle()
//         {
//             // var settings = TMP_Settings.GetSettings();
//             //设置字体为空，防止打包时被引用
//             //   TMP_Settings.defaultFontAsset
//             // 使用反射获取私有字段 defaultFontAsset
//             return;
//             var settings1 =
//                 AssetDatabase.LoadAssetAtPath<TMP_Settings>("Assets/Plugins/TextMesh Pro/Resources/TMP Settings.asset");
//             var settings2 =
//                 AssetDatabase.LoadAssetAtPath<TMP_Settings>("Assets/Plugins/TextMesh Pro/TMP Settings.asset");
//             var fontAsset =
//                 AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/Game/Font/LocalResources/Normal.asset");
//             SetDefaultTMPFont(settings1, null);
//             SetDefaultTMPFont(settings2, null);
//         }
//         [Button]
//         public void FontPostHandle()
//         {
//             return;
//             var settings1 =
//                 AssetDatabase.LoadAssetAtPath<TMP_Settings>("Assets/Plugins/TextMesh Pro/Resources/TMP Settings.asset");
//             var settings2 =
//                 AssetDatabase.LoadAssetAtPath<TMP_Settings>("Assets/Plugins/TextMesh Pro/TMP Settings.asset");
//             var fontAsset =
//                 AssetDatabase.LoadAssetAtPath<TMP_FontAsset>("Assets/Game/Font/LocalResources/Normal.asset");
//             SetDefaultTMPFont(settings1, fontAsset);
//             SetDefaultTMPFont(settings2, fontAsset);
//         }
//
//         public void SetDefaultTMPFont(TMP_Settings tmpSettings, TMP_FontAsset font)
//         {
//             // 使用反射获取私有字段 defaultFontAsset
//             FieldInfo defaultFontField =
//                 typeof(TMP_Settings).GetField("m_defaultFontAsset", BindingFlags.NonPublic | BindingFlags.Instance);
//
//             if (defaultFontField == null)
//             {
//                 Debug.LogError("Unable to find defaultFontAsset field in TMP_Settings.");
//                 return;
//             }
//
//             // 设置默认字体
//             defaultFontField.SetValue(tmpSettings, font);
//
//             EditorUtility.SetDirty(tmpSettings);
//
//             if (font != null)
//             {
//                 Debug.Log("Default TMP font has been set to: " + font.name);
//             }
//         }
//
//         
//         [Button]
//         public void AddDefiniation()
//         {
//             ScriptingDefineSymbols.AddScriptingDefineSymbol(BuildTargetGroup.WebGL, "WX");
//         }
//
//         [Button]
//         public void RemoveDefiniation()
//         {
//             ScriptingDefineSymbols.RemoveScriptingDefineSymbol(BuildTargetGroup.WebGL, "WX");
//         }
//
//         [Button("清空场景,只打包首场景", ButtonHeight = 40)]
//         public void DisableAllScenesExceptFirst()
//         {
//             // 获取当前构建设置中的所有场景
//             EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;
//             var currentScene = EditorSceneManager.GetActiveScene();
//             for (var i = 0; i < scenes.Length; i++)
//             {
//                 if (scenes[i].path == currentScene.path)
//                 {
//                     //交换
//                     if (scenes.Length > 1)
//                     {
//                         // 交换当前活动场景与第一个场景的位置
//                         (scenes[0], scenes[i]) = (scenes[i], scenes[0]);
//                     }
//
//                     break;
//                 }
//             }
//
//             // 禁用除第一个场景之外的所有场景
//             for (var i = 1; i < scenes.Length; i++)
//             {
//                 scenes[i].enabled = false;
//             }
//
//             // 将修改后的场景数组重新赋值给EditorBuildSettings.scenes
//             EditorBuildSettings.scenes = scenes;
//
//             //保存当前场景
//             EditorSceneManager.SaveOpenScenes();
//             
//             
//             Debug.Log("All scenes except the first one have been disabled.");
//         }
//
//         [Button("激活所有场景", ButtonHeight = 40)]
//         public void EnableAllScenes()
//         {
//             // 获取当前构建设置中的所有场景
//             EditorBuildSettingsScene[] scenes = EditorBuildSettings.scenes;
//
//             // 激活所有场景
//             for (var i = 0; i < scenes.Length; i++)
//             {
//                 scenes[i].enabled = true;
//             }
//
//             // 将修改后的场景数组重新赋值给EditorBuildSettings.scenes
//             EditorBuildSettings.scenes = scenes;
//
//             Debug.Log("All scenes have been enabled.");
//         }
//
//         [Button("打包-不包括资源", ButtonHeight = 40)]
//         public void BuildOnlyCode()
//         {
//            BuildPackage();
//            
//            UpLoadPackage();
//         }
//     }
// }