﻿namespace GameDevKitEditor
{
    public interface IBuild
    {
       
        /// <summary>
        /// 构建 AssetBundle并上传
        /// </summary>
        public void BuildAssetBundle();
        
        /// <summary>
        /// 构建 底包或安装包，不会打资源和上传资源。
        /// </summary>
        public void BuildPackage();
        
        /// <summary>
        /// 上传 AssetBundle 到oss 并更新到服务器
        /// </summary>
        public void UpLoadAssetBundle();
        
        /// <summary>
        /// 上传 底包或安装包
        /// </summary>
        public void UpLoadPackage();

        /// <summary>
        /// 发布 AssetBundle, 调用服务器接口进行上报
        /// </summary>
        public void PublishAssetBundle();
        
        /// <summary>
        /// 发布 Package，
        /// 微信小游戏，会上传到微信小游戏
        /// android会上报到服务器有新版本
        /// </summary>
        public void PublishPackage();
        
        public string DowloadPath();

        /// <summary>
        /// 自己的电脑打包，综合了清除，打包，拷贝，下载
        /// </summary>
        public void LocalBuild();
        
        /// <summary>
        /// 提供给远程Jenkins打包
        /// </summary>
        public void RemoteBuild();

    }
}