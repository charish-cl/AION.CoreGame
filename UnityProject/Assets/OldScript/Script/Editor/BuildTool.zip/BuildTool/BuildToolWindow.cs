using HybridCLR.Editor;
using AION.CoreFramework.Editor;
using Sirenix.OdinInspector;
using Sirenix.OdinInspector.Editor;
using UnityEditor;
using UnityEngine;

namespace GameDevKitEditor.BuildTool
{
    [TreeWindow("打包工具")]
    public class BuildWindow : OdinEditorWindow
    {
        private const string EnableHybridClrScriptingDefineSymbol = "ENABLE_HYBRIDCLR";

        protected override void OnEnable()
        {
            LoadBuildconfig("OnEnable");
        }

        private void OnFocus()
        {
            LoadBuildconfig("OnFocus");
        }
        
        private void OnValidate()
        {
            LoadBuildconfig("OnValidate");
        }

        private void LoadBuildconfig(string tag)
        {
            if (config == null)
            {
                config = BuildTool.BuildConfig;
            }
            RefrehshWindow();
            // Debug.Log($"BuildWindow after {tag} " + config + BuildTargetWindow);
        }


        [OnValueChanged("SetHybridCLR")] [LabelText("是否启用HybridCLR")]
        public bool IsEnableHybridCLR = false;
        public void SetHybridCLR()
        {
            if (IsEnableHybridCLR)
            {
                ScriptingDefineSymbols.AddScriptingDefineSymbol(EnableHybridClrScriptingDefineSymbol);
                SettingsUtil.Enable = true;
            }
            else
            {
                ScriptingDefineSymbols.RemoveScriptingDefineSymbol(EnableHybridClrScriptingDefineSymbol);
                SettingsUtil.Enable = false;
            }
        }

        [ShowInInspector]
        [LabelText("ActiveBuildTarget")]
        [ReadOnly]
        public string ActiveBuildTarget;

        
        private IBuild BuildInterface=>BuildTargetWindow as IBuild;
        
        [Button("Save（必须保存才能打包）")]
        public void RefrehshWindow ()
        {
            ActiveBuildTarget = EditorUserBuildSettings.activeBuildTarget.ToString();
            BuildTool.GenerateVersionInfo(BuildTool.GetInternalResourceVersionInResourceBuilder());
            PlayerSettings.bundleVersion = BuildTool.BuildConfig.Version;
            // Debug.Log( " RefrehshWindow PlayerSettings.bundleVersion " 
            //                             + PlayerSettings.bundleVersion 
            //                             + " Platform " + config.Platform
            //                             + " Channel " + config.Channel + BuildTargetWindow);
            if (config.Platform == Platform.Android)
            {
                if (BuildTargetWindow == null || 
                    !(BuildTargetWindow is AndroidBuildWindow))
                {
                    // Debug.Log(BuildTargetWindow + "create AndroidBuildWindow");
                    BuildTargetWindow = CreateInstance<AndroidBuildWindow>();
                }
            } else if (config.Platform == Platform.WebGL && 
                       config.Channel == Channel.WXMini)
            {
                if (BuildTargetWindow == null || 
                    !(BuildTargetWindow is WXBuildWindow))
                {
                    // Debug.Log(BuildTargetWindow + "create WXBuildWindow");
                    BuildTargetWindow = CreateInstance<WXBuildWindow>();
                }
            } else if (config.Platform == Platform.MacOS)
            {
                if (BuildTargetWindow == null || 
                    !(BuildTargetWindow is MacOSBuildWindow))
                {
                    // Debug.Log(BuildTargetWindow + "create MacOSBuildWindow");
                    BuildTargetWindow = CreateInstance<MacOSBuildWindow>();
                }
            }
            BuildTool.SaveBuildConfig();
        }

        [InlineEditor]
        public BuildConfig config;

        [ShowInInspector]
        public OdinEditorWindow BuildTargetWindow ;


        [Button("获取配置", ButtonHeight = 80)]
        public void GetConfig()
        {
            config = BuildTool.BuildConfig;
            RefrehshWindow();
        }

        [MenuItem("打包工具/打包窗口")]
        private static void OpenWindow()
        {
            GetWindow<BuildWindow>().Show();
        }

        [HorizontalGroup]
        [Button("编译DLL", ButtonHeight = 40)]
        public void BuildDll()
        {
            BuildTool.CompileDll();
        }

        [HorizontalGroup("Resource")]
        [Button("仅打资源", ButtonHeight = 40)]
        public void BuildAssetBundle()
        {
            BuildInterface.BuildAssetBundle();
        }

        [HorizontalGroup("Resource")]
        [Button("仅打资源上传", ButtonHeight = 40)]
        public void BuildResource()
        {
            BuildInterface.BuildAssetBundle();
            BuildInterface.UpLoadAssetBundle();
            BuildInterface.PublishAssetBundle();
        }

        [Button("上传版本文件", ButtonHeight = 40)]
        public void UploadVersionFile()
        {
            BuildInterface.PublishAssetBundle();
        }
        [Button("拷贝资源", ButtonHeight = 40)]
        public void CopyAssetBundle()
        {
           BuildTool.CopyResource();
        }

        [Button("打包安装", ButtonHeight = 40)]
        public void BuildPackageInstall()
        {
            BuildInterface.BuildPackage();
            Debug.Log("打 Package 成功");
            Debug.Log("安装");
            (BuildInterface as AndroidBuildWindow).Install();
        }
        
        //一键打包，综合了清除，打包，拷贝，下载
        [GUIColor(0, 1, 0)]
        [HorizontalGroup("Bottom")]
        [Button("本地一键打包", ButtonSizes.Large, ButtonHeight = 50)]
        public void LocalBuild()
        {
            BuildInterface.LocalBuild();
        }
        
        [HorizontalGroup("Bottom")]
        [Button("远程打包", ButtonSizes.Large, ButtonHeight = 50), GUIColor(1, 0.2f, 0)]
        public void RemoteBuild()
        {
            BuildInterface.RemoteBuild();
        }
        
        [Button("构建", ButtonHeight = 40)]
        public void Build()
        {
            // BuildInterface.BuildAssetBundle();
            BuildInterface.BuildPackage();
        }
        [Button("上传", ButtonHeight = 40)]
        public void UpLoad()
        {
            BuildInterface.UpLoadAssetBundle();
            BuildInterface.UpLoadPackage();
        }
        
        
        [Button("发布", ButtonHeight = 40)]
        public void Publish()
        {
            BuildInterface.PublishPackage();
        }

        [Button("打包地图动态资源、上传",ButtonHeight = 40)]
        public void BuildDynamicAB()
        {
            BuildTool.BuildDynamicAssetBundleAndUpload();
        }

    }
}