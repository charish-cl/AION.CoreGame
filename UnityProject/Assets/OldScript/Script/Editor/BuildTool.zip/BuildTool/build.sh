#!/bin/sh

mkdir ../Logs
# 这里使用 batchmode 会打不出android包。没找到原因。
/Applications/Unity/Hub/Editor/2022.3.17f1c1/Unity.app/Contents/MacOS/Unity -projectPath \
  ./  \
  -quit \
   -executeMethod BuildToolForJenkins.OneKeyBuild   \
   Platform-Android -logFile ../Logs/build.txt