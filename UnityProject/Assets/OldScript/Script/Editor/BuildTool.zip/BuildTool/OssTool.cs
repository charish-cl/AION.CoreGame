﻿using System;
using Editor;
using UnityEngine;

namespace GameDevKitEditor.BuildTool
{
    public class OssTool
    {
        //TODO:目录结构
        /// <summary>
        /// 
        /// </summary>
        /// <param name="folderName">源文件</param>
        /// <param name="uploadFilePath">目标路径</param>
        /// <returns></returns>
        public static void UpLoadOssFolder(string folderName,string uploadFilePath)
        {
            //上传到阿里云OSS
            Debug.Log($"{BuildTool.Flag} folderName: " + folderName);
            CreateFolder(uploadFilePath);

            //上传
            string upLoadCommand = $" cp {folderName} {uploadFilePath} -r ";

            if (!CommandTool.RunCommand("ossutil", upLoadCommand))
            {
                throw new Exception($"{BuildTool.Flag} upload oss failed " + folderName);
             
            }

        }

        private static void CreateFolder(string folderName)
        {
            //创建文件夹
            string createFolderCommand = $" mkdir {folderName}";
            //新建文件夹，显示日志
            if (!CommandTool.RunCommand("ossutil", createFolderCommand))
            {
                throw new Exception($"{BuildTool.Flag} create folderName failed " + folderName);
            }
        }


        public static void UpLoadOssFile(string fileName,string uploadFilePath)
        {
            //上传到阿里云OSS
            Debug.Log($"{BuildTool.Flag} fileName: " + fileName);
            
            string upLoadCommand = $" cp {fileName} {uploadFilePath} -r ";
            
            if (!CommandTool.RunCommand("ossutil", upLoadCommand))
            {
                throw new Exception($"{BuildTool.Flag} upload oss failed " + fileName);
                
            }
        }
    }
}