using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using GameFramework.Resource;
using HybridCLR.Editor.Commands;
using AION.CoreFramework;
using StarForce.Editor.ResourceTools;
using UGFExtensions.Build.Editor;
using UnityEditor;
using UnityEngine;
using UnityGameFramework.Editor.ResourceTools;
using Debug = UnityEngine.Debug;

namespace GameDevKitEditor.BuildTool
{
    public class BuildTool
    {
        public static string Flag = "BuildToolForJenkins";
        public static string AbVersionCode;
        private static BuildConfig _buildConfig;

        public static string BuildConfigFile = "Build/BuildConfig.txt";

        public static BuildConfig BuildConfig
        {
            get
            {
                bool isCreate = false;
                if (isCreate = _buildConfig == null)
                {
                    _buildConfig =
                        IOUtility.LoadObject<BuildConfig>(BuildConfigFile);
                    // Debug.Log($"{Flag} _buildConfig load finish " + _buildConfig);
                }

                if (_buildConfig == null)
                {
                    // 当本地没有 BuildConfigFile 文件时,_buildConfig会为空
                    _buildConfig = new BuildConfig();
                    SaveBuildConfig();
                }

                // Debug.Log($"{Flag} _buildConfig {isCreate} ");
                return _buildConfig;
            }
        }

        public static void SaveBuildConfig()
        {
            BuildConfig.SaveBuildInfo();
            BuildConfig.SaveBuildPackageInfo();
            IOUtility.CreateDirectoryIfNotExists("Build");
            _buildConfig.SaveObject(BuildConfigFile);
        }

        public static void GetJenkinsParam()
        {
            // 泛型方法，用于将字符串转换为枚举
            T ConvertStringToEnum<T>(string value) where T : struct
            {
                if (Enum.TryParse<T>(value, true, out T result))
                {
                    // Debug.Log($"{Flag} GetJenkinsParam name {value} {result.ToString()}" );
                    return result;
                }
                else
                {
                    throw new ArgumentException($"Unable to convert '{value}' to {typeof(T).Name}.");
                }
            }

            // 使用泛型方法将字符串转换为枚举并赋值
            BuildConfig.Platform = ConvertStringToEnum<Platform>(GetJenkinsParameter(nameof(BuildConfig.Platform)));
            BuildConfig.Channel = ConvertStringToEnum<Channel>(GetJenkinsParameter(nameof(BuildConfig.Channel)));
            PlayerSettings.bundleVersion = BuildConfig.Version = GetJenkinsParameter(nameof(BuildConfig.Version));
            BuildConfig.BuildType = ConvertStringToEnum<BuildType>(GetJenkinsParameter(nameof(BuildConfig.BuildType)));
            BuildConfig.BuildEnvironment =
                ConvertStringToEnum<BuildEnvironment>(GetJenkinsParameter(nameof(BuildConfig.BuildEnvironment)));
            BuildConfig.InternalGameVersion =
                Convert.ToInt32(GetJenkinsParameter(nameof(BuildConfig.InternalGameVersion)));
            BuildConfig.GitBranch = GetJenkinsParameter(nameof(BuildConfig.GitBranch));

            SaveBuildConfig();

            // Debug.Log(
            //     $"从Jenkins获取变量 3： {Flag} InitBuildConfig  Platform:{BuildConfig.Platform}" +
            //     $" PlayerSettings.bundleVersion:{PlayerSettings.bundleVersion}" +
            //     $" Application.version:{Application.version}" +
            //     $" Channel:{BuildConfig.Channel}" +
            //     $" Version:{BuildConfig.Version}" +
            //     $" BuildType:{BuildConfig.BuildType} " +
            //     $"BuildEnvironment:{BuildConfig.BuildEnvironment} InternalGameVersion:{BuildConfig.InternalGameVersion}");
        }

        public static void ClearABRes()
        {
            Debug.Log($"{Flag} ClearABRes start");
            string streamingAssetsPath = Application.streamingAssetsPath;
            //没有文件夹则创建
            if (!Directory.Exists(streamingAssetsPath))
            {
                Directory.CreateDirectory(streamingAssetsPath);
            }

            string[] files = Directory.GetFiles(streamingAssetsPath, "*.*", SearchOption.AllDirectories);
            foreach (string file in files)
            {
                if (!(file.EndsWith(".gitkeep") || file.EndsWith(".json")))
                {
                    File.Delete(file);
                }
            }

            AssetDatabase.Refresh();
            Debug.Log($"{Flag}StreamingAssets folder cleared except for .gitkeep file.");
            Debug.Log($"{Flag}ClearABRes end");
        }

        public static void BuildResource(string configFile = null)
        {
            var assetBundlePath = BuildConfig.LocalAssetBundlePath;
            if (!Directory.Exists(assetBundlePath))
            {
                Directory.CreateDirectory(assetBundlePath);
            }

            var resourceBuilderForJenkins = new ResourceBuilderForJenkins();
            // warning
            // init 的方法,已经把 resource version +1 了
            if (!resourceBuilderForJenkins.Init())
            {
                throw new Exception($"{Flag}BuildResource init failed");
            }
            GenerateVersionInfo(resourceBuilderForJenkins.m_Controller.InternalResourceVersion);
            // 将打包的资源版本号更新到buildinfo
            SaveBuildConfig();
            // 获取 InternalResourceVersion 
            // Debug.Log($"{Flag} BuildResource start" +
            //           $" {BuildConfig.InternalGameVersion} " +
            //           $" {BuildConfig.InternalResourceVersion} " +
            //           $" {BuildConfig.Version} " +
            //           $" {BuildConfig.UploadAssetBundlePath} " +
            //           $" {BuildConfig.CDNAssetBundleUrl} ");
            //刷新规则
            ResourceRuleEditorUtility.RefreshResourceCollection(configFile);

            switch (BuildConfig.Platform.ToString())
            {
                case "Windows":
                    resourceBuilderForJenkins.m_Controller.Platforms =
                        UnityGameFramework.Editor.ResourceTools.Platform.Windows;
                    break;
                case "Android":
                    resourceBuilderForJenkins.m_Controller.Platforms =
                        UnityGameFramework.Editor.ResourceTools.Platform.Android;
                    break;
                case "IOS":
                    resourceBuilderForJenkins.m_Controller.Platforms =
                        UnityGameFramework.Editor.ResourceTools.Platform.IOS;
                    break;
                case "MacOS":
                    resourceBuilderForJenkins.m_Controller.Platforms =
                        UnityGameFramework.Editor.ResourceTools.Platform.MacOS;
                    break;
                case "WebGL":
                    resourceBuilderForJenkins.m_Controller.Platforms =
                        UnityGameFramework.Editor.ResourceTools.Platform.WebGL;
                    break;
            }

            resourceBuilderForJenkins.m_Controller.OutputDirectory = BuildConfig.LocalAssetBundlePath;

            // Debug.Log($"输出目录： {resourceBuilderForJenkins.m_Controller.OutputDirectory}");
            if (!resourceBuilderForJenkins.BuildResources())
            {
                throw new Exception($"{Flag}BuildResource failed");
            }

            GenerateVersionInfo(GetInternalResourceVersionInResourceBuilder());
            SaveBuildConfig();
            Debug.Log($"{Flag}BuildResource success {BuildConfig.InternalResourceVersion}  {BuildConfig.CDNAssetBundleUrl}");
        }

        public static void CopyResource()
        {
            Debug.Log($"{Flag}CopyResource start {BuildConfig.InternalResourceVersion} {AbVersionCode}  {BuildConfig.CDNAssetBundleUrl}");
            string sourcePath =
                $"{BuildConfig.LocalAssetBundlePath}/Package/{AbVersionCode}/{BuildConfig.Platform.ToString()}";
            string destPath = Application.streamingAssetsPath;
            Debug.Log($"{Flag}Copying AssetBundle from " + sourcePath + " to " + destPath);
            if (!Directory.Exists(sourcePath))
            {
                throw new Exception("Source directory does not exist: " + sourcePath);
            }

            if (!Directory.Exists(destPath))
            {
                Directory.CreateDirectory(destPath);
            }

            CopyAllFilesRecursively(sourcePath, destPath);
            AssetDatabase.Refresh();
            Debug.Log($"{Flag}CopyResource success");
        }


        /// <summary>
        /// 最后面不要加斜杠
        /// </summary>
        /// <param name="sourceDir"></param>
        /// <param name="targetDir"></param>
        private static void CopyAllFilesRecursively(string sourceDir, string targetDir)
        {
            foreach (string dirPath in Directory.GetDirectories(sourceDir, "*", SearchOption.AllDirectories))
            {
                Directory.CreateDirectory(dirPath.Replace(sourceDir, targetDir));
            }

            foreach (string newPath in Directory.GetFiles(sourceDir, "*.*", SearchOption.AllDirectories))
            {
                File.Copy(newPath, newPath.Replace(sourceDir, targetDir), true);
            }
        }

        /**
         * 从 ResourceBuilder 获取 InternalResourceVersion 信息
         * 注意：
         *  打资源前：读取的是这次打资源的 InternalResourceVersion
         *      打完资源 InternalResourceVersion 会自增1并保存。
         *  打资源后：读取的是这次打资源的 InternalResourceVersion + 1。
         *  所以如果是打完资源后要获取 上一次资源的 InternalResourceVersion 需要减 1
         * @param callAfterBuildResource true : 在打资源钱
         */
        public static void GenerateVersionInfo(int internalResourceVersion)
        {
            // Debug.Log(
            //     $"{Flag} GetVersionInfo start VersionCode: {AbVersionCode} " +
            //     $" InternalGameVersion : {BuildConfig.InternalGameVersion}");
            // 设置进去生成资源对应版本号的目录
            BuildConfig.InternalResourceVersion = internalResourceVersion;
            AbVersionCode =
                VersionInfoData.GeneateResourceFolder(PlayerSettings.bundleVersion, internalResourceVersion);
            // Debug.Log(
            //     $"{Flag} GetVersionInfo end  VersionCode: {AbVersionCode} " +
            //     $" InternalGameVersion : {BuildConfig.InternalGameVersion}");
        }

        /**
         * 获取 ResourceBuilder 的 InternalResourceVersion
         */
        public static int GetInternalResourceVersionInResourceBuilder()
        {
            var resourceBuilder = AssetDatabase.LoadAssetAtPath<TextAsset>(EditorPathUtility.ResourceBuilderPath);
            //解析xml
            XmlDocument xmlDoc = new XmlDocument();
            // 加载XML字符串
            xmlDoc.LoadXml(resourceBuilder.text);
            // 获取根节点
            XmlNode root = xmlDoc.DocumentElement;

            // 获取InternalResourceVersion节点的值
            XmlNode internalResourceVersionNode = root.SelectSingleNode("//InternalResourceVersion");
            int result = int.Parse(internalResourceVersionNode.InnerText);
            // Debug.Log(
            //     $"{Flag}  InternalGameVersion : {result}");
            return result;
        }

        public static void OneKeyBuild()
        {
            BuildPreHelper.SetResourceMode(ResourceMode.Updatable);
#if UNITY_EDITOR_OSX && ENABLE_HYBRIDCLR
            InstallerController controller = new InstallerController();
            if (!controller.HasInstalledHybridCLR())
            {
                controller.InstallDefaultHybridCLR(); 
               
            }
            if (!File.Exists("Assets/Game/HybridCLR/AOTGenericReferences.cs"))
            {
                //重新生成下
                PrebuildCommand.GenerateAll();
            }
#endif

            //获取参数
            GetJenkinsParam();
            // todo nightq CompileDll();
            Debug.Log($"{Flag}OneKeyBuild start");
            if (BuildConfig.Platform == Platform.Android)
            {
                Build = ScriptableObject.CreateInstance<AndroidBuildWindow>();
            }
            else if (BuildConfig.Platform == Platform.WebGL
                     && BuildConfig.Channel == Channel.WXMini)
            {
                Build = ScriptableObject.CreateInstance<WXBuildWindow>();
            }
            else if (BuildConfig.Platform == Platform.MacOS)
            {
                Build = ScriptableObject.CreateInstance<MacOSBuildWindow>();
            }
            else
            {
                throw new Exception(" 不支持 ");
            }

            try
            {
                Build.RemoteBuild();
                // 如果 Build.RemoteBuild() 执行成功，发送成功消息
                SendFlyBookRobot(Build.DowloadPath(), true);
            }
            catch (Exception e)
            {
                Debug.LogError(e);
                SendFlyBookRobot(Build.DowloadPath(), false, e.Message);
            }
        }

        private static IBuild Build;

        /// <summary>
        ///解释jekins 传输的参数
        /// </summary>
        /// <param name="name"></param>
        /// 实例：
        ///  -batchmode -executeMethod BuildToolForJenkins.OneKeyBuild Platform-Android -quit   
        /// <returns></returns>
        static string GetJenkinsParameter(string name)
        {
            foreach (string arg in Environment.GetCommandLineArgs())
            {
                if (arg.StartsWith(name))
                {
                    Debug.Log($"{Flag} GetJenkinsParameter name {name} {arg.Split("-"[0])[1]}");
                    return arg.Split("-"[0])[1];
                }
            }

            return null;
        }

        /// <summary>
        /// 上传ab资源
        /// </summary>
        /// <returns></returns>
        public static void UpLoadResourceToOSS()
        {
            GenerateVersionInfo(GetInternalResourceVersionInResourceBuilder());
            string folderName =
                Path.GetFullPath($"./AssetBundle/Full/{AbVersionCode}/{BuildConfig.Platform.ToString()}");
            OssTool.UpLoadOssFolder(folderName, BuildConfig.UploadAssetBundlePath);
        }


        /**
         * todo nightq 需要增加产品id和平台，渠道等信息
         */
        public static async Task<bool> UpLoadVersionFile(string DowloadPath)
        {
            ResourceVersionDto resourceVersionDto = new ResourceVersionDto
            {
                AppVersion = BuildConfig.Version,
                ResVersion = Convert.ToUInt32(BuildConfig.InternalResourceVersion),
                BootVersion = Convert.ToUInt32(BuildConfig.InternalGameVersion),
                ResUrl = BuildConfig.CDNAssetBundleUrl,
                AppUrl =  CalculateMD5(Path.Combine(Application.streamingAssetsPath, "GameFrameworkVersion.dat")),
                Platform = BuildConfig.Platform.ToString(),
                Channel = BuildConfig.Channel.ToString(),
                ProjectId = BuildConfig.ProjectID
            };
           
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post, "http://47.108.58.49/version/resource/upload");
            request.Content = FormUtility.GetFormDataContent(resourceVersionDto);
            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();

            return response.IsSuccessStatusCode;
        }

        
        // 计算指定文件的MD5值
        public static string CalculateMD5(string filePath)
        {
            // 创建一个 MD5 对象
            using (MD5 md5 = MD5.Create())
            {
                // 打开文件流，读取文件
                using (FileStream fileStream = File.OpenRead(filePath))
                {
                    // 计算并获取文件的MD5哈希值
                    byte[] hashBytes = md5.ComputeHash(fileStream);

                    // 将哈希字节数组转为十六进制字符串
                    return BitConverter.ToString(hashBytes).Replace("-", "").ToLowerInvariant();
                }
            }
        }
        public static void CompileDll()
        {
            //不启用的话编译也没意义，也用不到dll
#if !ENABLE_HYBRIDCLR
            return;
#endif
            Debug.Log("编译DLL");
            HybridCLRBuilderController controller = new HybridCLRBuilderController();
            BuildTarget buildTarget = (BuildTarget)0;
            BuildConfig.GetTarget(ref buildTarget);

            CompileDllCommand.CompileDll(buildTarget);
            controller.CopyDllAssets(buildTarget);
        }

        /// <summary>
        /// 发送消息给机器人
        /// </summary>
        /// <param name="title"></param>
        /// <param name="sb"></param>
        public static async void SendMessageToRobot(string title, string message)
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage(HttpMethod.Post,
                "https://open.feishu.cn/open-apis/bot/v2/hook/92eee745-a0a7-455f-9a84-60d69481fc4f");
            // 使用字符串内插
            var jsonContent = $@"{{
            ""msg_type"": ""post"",
            ""content"": {{
                ""post"": {{
                    ""zh_cn"": {{
                        ""title"": ""{title}"",
                        ""content"": [[
                            {{
                                ""tag"": ""text"",
                                ""text"": ""{message}""
                            }}
                        ]]
                    }}
                }}
            }}
        }}";

            var content = new StringContent(jsonContent, Encoding.UTF8, "application/json");
            request.Content = content;

            var response = await client.SendAsync(request);
            response.EnsureSuccessStatusCode();
        }

        //通知打包机器人
        public static void SendFlyBookRobot(string downloadUrl,
            bool isSuccessful = true, string errorText = "")
        {
            string title; // 标题
            if (isSuccessful)
            {
                title = $"{BuildConfig.ProjectName} 打包成功";
            }
            else
            {
                title = $"{BuildConfig.ProjectName} 打包失败 ERROR:{errorText}";
            }

            //    1. 项目名，平台名，渠道名，版本名。这次打包的资源号。打包类型。打包环境。安装包下载地址。
            StringBuilder sb = new StringBuilder();
            //这里换行会报错 不能使用AppendLine()
            sb.Append($"项目名: {BuildConfig.ProjectName} \\n");
            sb.Append($"打包分支: {BuildConfig.GitBranch} \\n");
            sb.Append($"平台名: {BuildConfig.Platform} \\n");
            sb.Append($"渠道名: {BuildConfig.Channel} \\n");
            sb.Append($"版本名: {BuildConfig.Version} \\n");
            sb.Append($"这次打包的资源号: {BuildConfig.InternalResourceVersion} \\n");
            sb.Append($"打包类型: {BuildConfig.BuildType} \\n");
            sb.Append($"打包环境: {BuildConfig.BuildEnvironment} \\n");

            if (isSuccessful)
            {
                sb.Append($"安装包下载地址: {downloadUrl} ");
            }

            // 使用字符串内插
            SendMessageToRobot(title, sb.ToString());
        }


        // 打包输出的目录
        public static string GetOutPutFolder()
        {
            return $"./Build/{BuildConfig.Platform}/{BuildConfig.Channel}";
        }

        public static string GetCurrentGitBranch()
        {
            // 使用ProcessStartInfo启动git bash命令
            ProcessStartInfo startInfo = new ProcessStartInfo
            {
                FileName = "git",
                Arguments = "rev-parse --abbrev-ref HEAD",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                CreateNoWindow = true
            };

            try
            {
                // 启动进程
                using (Process process = Process.Start(startInfo))
                {
                    // 获取命令的输出结果
                    return process.StandardOutput.ReadToEnd().Trim();
                }
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            return "Unknown";
        }

        /// <summary>
        /// 打包地图资源并上传oss
        /// </summary>
        public static void BuildDynamicAssetBundleAndUpload()
        {
            var buildDynamicAssetBundle = _buildConfig.LocalAssetBundlePath + "/Working/" + _buildConfig.Platform;
            

            BuildResource("Assets/Game/BuildConfig/DynamicRuleEditor.asset");
            
            if (!Directory.Exists(buildDynamicAssetBundle))
            {
                throw new Exception("Working目录不存在");
            }
            
            var stopwatch = new Stopwatch();
            stopwatch.Start(); // 开始计时

            // 指定要搜索的目录

            //创建一个临时目录，用于存放打包后的资源
            string tempPath = Path.GetFullPath("./Temp/DynamicAssetBundle");
            if (!Directory.Exists(tempPath))
            {
                Directory.CreateDirectory(tempPath);
            }

            // 复制资源到临时目录
            string[] files = Directory.GetFiles(buildDynamicAssetBundle, "*.*", SearchOption.AllDirectories)
                .Where(x => !x.EndsWith(".manifest")).ToArray();
            foreach (string file in files)
            {
                string destPath = Path.GetFullPath(file.Replace(buildDynamicAssetBundle, tempPath));
                if (!Directory.Exists(Path.GetDirectoryName(destPath)))
                {
                    Directory.CreateDirectory(Path.GetDirectoryName(destPath));
                }

                File.Copy(file, destPath, true);
            }

            // 上传资源到oss
            string ossFolder = _buildConfig.UploadAssetBundlePath + "/Dynamic";
            Debug.Log($"上传动态资源到oss {ossFolder}");
            
            _buildConfig.SaveDynamicAssetBundlePath();
            
            
            Task.Run(() => OssTool.UpLoadOssFolder(tempPath, ossFolder)).ContinueWith(t =>
            {
                stopwatch.Stop(); // 停止计时
                Debug.Log($"BuildDynamicAssetBundleAndUpload 耗时：{stopwatch.ElapsedMilliseconds} ms");
                // 删除临时目录
                Directory.Delete(Path.GetFullPath("./Temp/DynamicAssetBundle"), true);
            });
        }
    }
}