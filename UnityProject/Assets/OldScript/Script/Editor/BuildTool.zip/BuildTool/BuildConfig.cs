﻿using System;
using System.IO;
using System.Text;
using GameFramework;
using AION.CoreFramework;
using Sirenix.OdinInspector;
using UGFExtensions.Build.Editor;
using UnityEditor;
using UnityEngine;
using UnityEngine.Serialization;
using UnityGameFramework.Runtime;

namespace GameDevKitEditor.BuildTool
{
    /// <summary>
    /// 表示构建的目标平台。
    /// </summary>
    public enum Platform
    {
        Android,
        IOS,
        WebGL,
        Windows,
        MacOS
    }

    /// <summary>
    /// 表示应用发布的渠道。
    /// </summary>
    public enum Channel
    {
        // GooglePlay,
        // AppStore,
        // WX,
        // DouYin,
        GooglePlay,
        AppStore,
        Official,
        WXMini,
        DouYinMini
    }

    /// <summary>
    /// 表示构建的类型。
    /// </summary>
    public enum BuildType
    {
        /// <summary>
        /// 只打资源包。
        /// </summary>
        ResourceOnly,

        /// <summary>
        /// 打热更包。
        /// </summary>
        Hotfix,

        /// <summary>
        /// 只打应用包。
        /// </summary>
        AppOnly
    }

    /// <summary>
    /// 表示构建的环境。
    /// </summary>
    public enum BuildEnvironment
    {
        /// <summary>
        /// 测试包，对于Android是APK。
        /// </summary>
        Debug,

        /// <summary>
        /// 发布包，对于Android是AAB。
        /// </summary>
        Release,
        
        PreRelease // 为以后可能的与发布预留
    }
    
    // 快速构建
    public enum QuickBuildModel
    {
        WX_Mini,
        Douyin_Mini
    }
    /**
     * //全路径：oss://qiyu-base/打包环境/AssetBundle/项目名/平台名/渠道名/版本号_资源号
     *
     * ab资源目录：
     * https://privatecloud.nightq.top/Debug/AssetBundle/WebGL/GooglePlay/0_0_1_67
     * oss://qiyu-base/Debug/AssetBundle/WebGL/GooglePlay/0_0_1_67
     * 
     * https://privatecloud.nightq.top/Release/AssetBundle/WebGL/GooglePlay/0_0_1_67
     * oss://qiyu-base/Release/AssetBundle/WebGL/GooglePlay/0_0_1_67
     *
     * 底包目录：
     * https://privatecloud.nightq.top/Debug/Package/WebGL/GooglePlay/0_0_1_67
     * oss://qiyu-base/Debug/Package/WebGL/GooglePlay/0_0_1_67
     *
     * 安装包目录：
     * https://privatecloud.nightq.top/Release/Package/Android/GooglePlay/[文件名]
     * https://privatecloud.nightq.top/Debug/Package/Android/GooglePlay/[文件名]
     */
    public class BuildConfig:SerializedScriptableObject
    {
        [LabelText("项目ID")]
        public uint ProjectID = 0;
        
        [LabelText("是否使用本地CDN")]
        public bool UserLocalCDN;

        [LabelText("打包时是否打包图集")]
        public bool IsBuildAtals = false;
        /// <summary>
        /// 目标平台。
        /// </summary>
        [LabelText("目标平台")]
        public Platform Platform = Platform.WebGL;

        /// <summary>
        /// 发布渠道。
        /// </summary>
        [LabelText("发布渠道")]
        public Channel Channel;

        /// <summary>
        /// git 分支
        /// </summary>
        [LabelText("Jenkins打包的Git分支")]
        public string GitBranch;

        /// <summary>
        /// 版本号，格式为1.1.111。
        /// </summary>
        [LabelText("版本号")]
        public string Version  = "0.0.1"; // 默认版本号

        /// <summary>
        /// 构建类型。
        /// </summary>
        [LabelText("构建类型")]
        public BuildType BuildType;

        /// <summary>
        /// 构建环境。
        /// </summary>
        [LabelText("构建环境")]
        public BuildEnvironment BuildEnvironment;

        [LabelText("描述")]
        public string Describe;


        /// <summary>
        /// 游戏内部版本号
        /// </summary>
        [LabelText("游戏内部版本号")]
        public int  InternalGameVersion;
        
        [Sirenix.OdinInspector.InfoBox("当前激活平台")]
        public string ActiveBuildTarget
        {
            get
            {
                return EditorUserBuildSettings.activeBuildTarget.ToString();
            }
        }

        #region 以下为只读属性

        // 资源目录格式：
        // https://privatecloud.nightq.top/[环境：Debug Release]/AssetBundle/[产品名]/[平台名]/[渠道名]/[包版本号_资源版本号]
        
        [ReadOnly]
        [LabelText("CDN上传前缀")]
        private string CDNUploadPrefix = "oss://qiyu-base";
        
        [ReadOnly]
        [LabelText("CDN下载前缀")]
        private string CDNPrefix = "https://privatecloud.nightq.top";
        
        // 用于存储 gf 的 AssetBundle 资源
        [ReadOnly]
        [LabelText("AssetBundle路径后缀")]
        private string CDNAssetBundleSuffix = "AssetBundle";
        
        // 用于底包或安装包：
        //  android ：apk，aab；
        //  小游戏：底包
        [ReadOnly]
        [LabelText("底包/安装包路径后缀")]
        private string CDNPackageSuffix = "Package";
        
       


        
        [ReadOnly]
        [LabelText("CDN上传微信小游戏底包/安装包目录")]
        public string UploadPackagePath
        {
            get
            {
                return $"{CDNUploadPrefix}/{BuildEnvironment}/{CDNPackageSuffix}/{ProjectName}/{Platform.ToString()}" +
                       $"/{Channel.ToString()}/{RemoteFolderName}";
            }
        }
        
        [ReadOnly]
        [LabelText("CDN上传AssetBundle目录")]
        public string UploadAssetBundlePath
        {
            get
            {
                return $"{CDNUploadPrefix}/{BuildEnvironment}/{CDNAssetBundleSuffix}/{ProjectName}/{Platform.ToString()}" +
                       $"/{Channel.ToString()}/{RemoteFolderName}";
            }
        }

        [ReadOnly]
        [LabelText("CDN下载微信小游戏底包/安装包目录")]
        public string CDNPackageUrl
        {
            get
            {
                return $"{CDNPrefix}/{BuildEnvironment}/{CDNPackageSuffix}/{ProjectName}/{Platform.ToString()}" +
                       $"/{Channel.ToString()}/{RemoteFolderName}";
            }
        }

        [ReadOnly]
        [LabelText("CDN下载AssetBundle目录")]
        public string CDNAssetBundleUrl
        {
            get
            {
                return $"{CDNPrefix}/{BuildEnvironment}/{CDNAssetBundleSuffix}/{ProjectName}/{Platform.ToString()}" +
                       $"/{Channel.ToString()}/{RemoteFolderName}";
            }
        }
        
        [ReadOnly]
        [LabelText("CDN下载动态资源目录")]
        public string DownloadDynamicUrl
        {
            get
            {
                return CDNAssetBundleUrl + "/Dynamic";
            }
        }
        [ReadOnly]
        //获取PlayerSetting中的ProductName
        public string ProjectName => Constant.ProjectName;
        // 内部使用内部项目名，不使用真名。PlayerSettings.productName
        
        // 资源版本号
        [LabelText("资源版本号")]
        public int m_InternalResourceVersion = 0;
        public int InternalResourceVersion
        {
            get => m_InternalResourceVersion;
            set => m_InternalResourceVersion = value;
        }

        //全路径：oss://qiyu-base/打包环境/AssetBundle/项目名/平台名/渠道名/版本号_资源号
        // 0.0.001_69
        public string RemoteFolderName
        {
            get
            {
                return VersionInfoData.GeneateResourceFolder(
                        PlayerSettings.bundleVersion, InternalResourceVersion);
            }
        }

        public string LocalAssetBundlePath =>Path.GetFullPath("./AssetBundle") ;

        #endregion
   
        public void LogBuildInfo(string tag)
        {
            var path = "Assets/Resources/Config/BuildInfo.txt";
            try
            {
                var m_BuildInfoTextAsset = AssetDatabase.LoadAssetAtPath<TextAsset>(path);
                Debug.Log(tag + $" LogBuildInfo.txt  : {m_BuildInfoTextAsset.text}");
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
        }

        public void SaveBuildPackageInfo()
        {
            var path = "Assets/Resources/Config/BuildPackageInfo.txt";

            BuildPackageInfo m_BuildInfo = null;
            try
            {
                var m_BuildInfoTextAsset = AssetDatabase.LoadAssetAtPath<TextAsset>(path);
                // Debug.Log($"SaveBuildPackageInfo.txt start : {m_BuildInfoTextAsset.text}");
                m_BuildInfo = LitJson.JsonMapper.ToObject<BuildPackageInfo>(m_BuildInfoTextAsset.text);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            if (m_BuildInfo == null)
            {
                m_BuildInfo = new BuildPackageInfo();
            }

            //底包号 渠道 项目ID都要保存
            m_BuildInfo.InternalGameVersion = InternalGameVersion;
            m_BuildInfo.Channel = Channel.ToString();
            m_BuildInfo.ProjectID = ProjectID;
            m_BuildInfo.BuildTime = DateTime.Now.ToString();
            m_BuildInfo.GitBranch = BuildTool.GetCurrentGitBranch();
            m_BuildInfo.BuildEnvironment = BuildEnvironment.ToString();
            m_BuildInfo.CDNPackageUrl = CDNPackageUrl;
           
            //保存到文件
            var json = LitJson.JsonMapper.ToJson(m_BuildInfo);
            System.IO.File.WriteAllText(path, json, Encoding.UTF8);
            AssetDatabase.Refresh();
            // Debug.Log($"SaveBuildPackageInfo.txt end : {json}");
        }
        
        public void SaveBuildInfo()
        {
            var path = "Assets/Resources/Config/BuildInfo.txt";
            BuildInfo m_BuildInfo = null;
            try
            {
                var m_BuildInfoTextAsset = AssetDatabase.LoadAssetAtPath<TextAsset>(path);
                // Debug.Log($"SaveBuildInfo.txt start : {m_BuildInfoTextAsset.text}");
                m_BuildInfo = LitJson.JsonMapper.ToObject<BuildInfo>(m_BuildInfoTextAsset.text);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }

            if (m_BuildInfo == null)
            {
                m_BuildInfo = new BuildInfo();
            }

            m_BuildInfo.CDNAssetBundleUrl = CDNAssetBundleUrl;
            m_BuildInfo.ResourceId = InternalResourceVersion;
            
            //保存到文件
            var json = LitJson.JsonMapper.ToJson(m_BuildInfo);
            System.IO.File.WriteAllText(path, json, Encoding.UTF8);
            AssetDatabase.Refresh();
            // Debug.Log($"更新BuildInfo.txt : {json}");
        }
        
        public void SaveDynamicAssetBundlePath()
        {
            var path = "Assets/Resources/Config/RemoteBuildInfo.txt";

            RemoteBuildInfo m_BuildInfo = null;
            try
            {
                var m_BuildInfoTextAsset = AssetDatabase.LoadAssetAtPath<TextAsset>(path);
                m_BuildInfo = LitJson.JsonMapper.ToObject<RemoteBuildInfo>(m_BuildInfoTextAsset.text);
            }
            catch (Exception e)
            {
                Console.WriteLine(e);
            }
            
            if (m_BuildInfo == null)
            {
                m_BuildInfo = new RemoteBuildInfo();
            }
            
            m_BuildInfo.DowloadDynamicUrl = DownloadDynamicUrl;
            //保存到文件
            var json = LitJson.JsonMapper.ToJson(m_BuildInfo);
            System.IO.File.WriteAllText(path, json, Encoding.UTF8);
            AssetDatabase.Refresh();
        }
        public void GetTarget(ref BuildTarget buildTarget)
        {
            switch (Platform.ToString())
            {
                case "Android":
                    buildTarget = BuildTarget.Android;
                    break;
                case "iOS":
                    buildTarget = BuildTarget.iOS;
                    break;
                case "WebGL":
                    buildTarget = BuildTarget.WebGL;
                    break;
                case "Windows":
                    buildTarget = BuildTarget.StandaloneWindows;
                    break;
                case "MacOS":
                    buildTarget = BuildTarget.StandaloneOSX;
                    break;
                
                default:
                    throw new Exception("未知的平台：" + Platform);
                    return;
            }
            
        }

      
    }
}