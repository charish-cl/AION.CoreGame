﻿using GameFramework.Resource;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityGameFramework.Runtime;

namespace GameDevKitEditor.BuildTool
{
    public  class BuildPreHelper
    {
        
        
        /// <summary>
        ///  设置Editor资源模式 
        /// </summary>
        public static void SetResourceMode(ResourceMode resourceMode)
        {
            // SpriteAtlasPacker.PackSpritesIntoAtlas();
            // if (EditorSceneManager.GetActiveScene().path != "Assets/Game/Scenes/Launch.unity")
            // {
            //     EditorSceneManager.OpenScene("Assets/Game/Scenes/Launch.unity");
            // }
            //
            // //查找场景中的
            // GameObject.FindObjectOfType<BaseComponent>().EditorResourceMode = false;
            //
            // GameObject.FindObjectOfType<ResourceComponent>().SetResourceMode(resourceMode);
            // //保存场景
            // EditorSceneManager.SaveScene(EditorSceneManager.GetActiveScene());
        }
    }
}